#include <ATen/mkldnn/Runtime.h>

namespace at { namespace native {

}}  // namespace at::native
