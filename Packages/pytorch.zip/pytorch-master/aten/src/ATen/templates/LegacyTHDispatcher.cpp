#include "ATen/LegacyTHDispatcher.h"

// ${generated_comment}

namespace at {

// template: legacy_type_method_definitions

}
