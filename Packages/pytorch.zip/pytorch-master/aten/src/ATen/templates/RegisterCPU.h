#pragma once

// ${generated_comment}

namespace at {

class Context;
void register_cpu_types(Context * context);

} // namespace at
