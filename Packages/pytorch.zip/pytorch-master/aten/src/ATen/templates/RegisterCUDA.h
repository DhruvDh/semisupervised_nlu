#pragma once

// ${generated_comment}

namespace at {

class Context;
void register_cuda_types(Context * context);

} // namespace at
