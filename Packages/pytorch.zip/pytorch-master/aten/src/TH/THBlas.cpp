#include <TH/THBlas.h>

#include <TH/generic/THBlas.cpp>
#include <TH/THGenerateAllTypes.h>
