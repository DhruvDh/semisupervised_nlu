#include <TH/THLapack.h>

#include <TH/generic/THLapack.cpp>
#include <TH/THGenerateFloatTypes.h>
